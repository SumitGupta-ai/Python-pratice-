#  Convert temperature from Celsius to Fahrenheit. 

celsius = float(input("Enter temperature in celsius: "))

fahrenheit = (celsius * 9/5) + 32

print(f"{celsius} c is equal to {fahrenheit:.2f}F")